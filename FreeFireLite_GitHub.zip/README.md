# FreeFireLite

This is a lightweight 3D shooter demo inspired by Free Fire.

## How to Play Online
- Go to **GitHub Pages** (after you enable it in repo settings).
- The game will be live at: `https://<your-username>.github.io/FreeFireLite/freefirelite.html`

## Android APK
- The `android/` folder contains an Android Studio project wrapping the HTML game in a WebView.
- Open in Android Studio → Build APK → install on your phone.

Enjoy! 🚀
